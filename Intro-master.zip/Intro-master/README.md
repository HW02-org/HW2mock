Intro
=====

Course materials for "Introduction to Data Science with R", a video course by RStudio and O'Reilly Media. To purchase the course, or watch sample lessons, visit [http://shop.oreilly.com/product/0636920034834.do](http://shop.oreilly.com/product/0636920034834.do).
